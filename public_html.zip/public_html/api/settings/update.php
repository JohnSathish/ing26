<?php
/**
 * Update Setting
 * Admin only
 */

if (!defined('API_ACCESS')) { define('API_ACCESS', true); }

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../middleware/csrf.php';

// Only allow PUT/PATCH
if (!in_array($_SERVER['REQUEST_METHOD'], ['PUT', 'PATCH'])) {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Require admin
requireAdmin();

// Validate CSRF
validateCSRF();

// Get key
$key = sanitizeInput($_GET['key'] ?? '', 'string');
$input = json_decode(file_get_contents('php://input'), true);

if (empty($key)) {
    $key = sanitizeInput($input['key'] ?? '', 'string');
}

if (empty($key)) {
    http_response_code(400);
    echo json_encode(['error' => 'Setting key is required']);
    exit;
}

$value = $input['value'] ?? '';
$type = sanitizeInput($input['type'] ?? 'text', 'string');

try {
    $db = Database::getInstance()->getConnection();
    
    // Update or insert
    $stmt = $db->prepare("
        INSERT INTO settings (key_name, value, type)
        VALUES (:key, :value, :type)
        ON DUPLICATE KEY UPDATE value = :value, type = :type
    ");
    
    $stmt->execute([
        'key' => $key,
        'value' => $value,
        'type' => $type
    ]);
    
    // Log action
    require_once __DIR__ . '/../utils/audit.php';
    auditLog('update', 'setting', $key);
    
    echo json_encode([
        'success' => true,
        'message' => 'Setting updated successfully'
    ]);
    
} catch (PDOException $e) {
    error_log("Settings update error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to update setting']);
}

